from django.apps import AppConfig


class PagesErrorConfig(AppConfig):
    name = 'pages_error'
