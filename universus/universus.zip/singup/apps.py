from django.apps import AppConfig


class SingupConfig(AppConfig):
    name = 'singup'
