from django.apps import AppConfig


class ExamBuilderConfig(AppConfig):
    name = 'exam_builder'
