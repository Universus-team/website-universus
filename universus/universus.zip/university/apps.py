from django.apps import AppConfig


class UniversityConfig(AppConfig):
    name = 'university'
